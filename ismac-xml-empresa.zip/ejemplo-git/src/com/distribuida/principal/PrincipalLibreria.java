package com.distribuida.principal;

public class PrincipalLibreria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
			System.out.println("AQUI VIENEN TODOS LOS MODULOS DEL PROYECTO");		
		
	}

}
